"""
ProRca Package

A package for generating synthetic data and performing root cause analysis.
"""

__version__ = "0.1.0"
